<template>
  <h1>OOPS!!</h1>
  <h2>YOU ARE UNAUTHORIZED</h2>
  <router-link :to="{name: 'Login Page'}"> LOGIN FIRST </router-link>
</template>

<script>
export default {

}
</script>

<style>

</style>