<template>
    <div class="gps">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path :fill="barFill()" d="M12 8C9.79 8 8 9.79 8 12C8 14.21 9.79 16 12 16C14.21 16 16 14.21 16 12C16 9.79 14.21 8 12 8ZM20.94 11C20.7135 8.97212 19.8042 7.08154 18.3613 5.63869C16.9185 4.19585 15.0279 3.28651 13 3.06V1H11V3.06C8.97212 3.28651 7.08154 4.19585 5.63869 5.63869C4.19585 7.08154 3.28651 8.97212 3.06 11H1V13H3.06C3.28651 15.0279 4.19585 16.9185 5.63869 18.3613C7.08154 19.8042 8.97212 20.7135 11 20.94V23H13V20.94C15.0279 20.7135 16.9185 19.8042 18.3613 18.3613C19.8042 16.9185 20.7135 15.0279 20.94 13H23V11H20.94ZM12 19C8.13 19 5 15.87 5 12C5 8.13 8.13 5 12 5C15.87 5 19 8.13 19 12C19 15.87 15.87 19 12 19Z"/>
      </svg>
    </div>
  </template>
  
  <script setup>
  import { watchEffect } from 'vue';
  
  const props = defineProps({
    status: Boolean,
  });

  function barFill() {
    const activeColor = '#34C759';
    const inactiveColor = '#D1D1D6';
    return props.status == true ? activeColor : inactiveColor;
  }
  
  watchEffect(() => {
    console.log('status changed:', props.status);
  });
  </script>
  