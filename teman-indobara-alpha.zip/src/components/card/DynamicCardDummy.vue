<template>
  <div class="card">
    <h1 class="text-[#353535]/60 ">Add New Panel</h1>
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M18.3333 31.6663V21.6663H8.33333V18.333H18.3333V8.33301H21.6667V18.333H31.6667V21.6663H21.6667V31.6663H18.3333Z" fill="#D1D1D1"/>
    </svg>
  </div>
</template>
  

<style scoped>
.card {
  @apply 
  cursor-pointer
  border-dashed border-4 border-spacing-2
  flex flex-col gap-4 min-w-full p-2 rounded-lg h-[330px]
  items-center justify-center
  hover:border-blue-300
}



</style>
  